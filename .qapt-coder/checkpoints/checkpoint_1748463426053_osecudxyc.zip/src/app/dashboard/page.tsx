"use client";

import MainLayout from "@/components/layout/MainLayout";
import { withAuth } from "@/components/auth/withAuth";

import { TodaySection } from "@/components/dashboard/TodaySection";
import { LeaseFunnel } from "@/components/dashboard/LeaseFunnel";
import { RecentlyViewed } from "@/components/dashboard/RecentlyViewed";
import { TasksSection } from "@/components/dashboard/TasksSection";
import { FinancialOverview } from "@/components/dashboard/FinancialOverview";
import { useDashboardData } from "@/hooks/useDashboard";

function DashboardPage() {
  const { data: dashboardData, isLoading } = useDashboardData();

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading dashboard...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Today Section */}
        <TodaySection data={dashboardData?.today} />

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-1 space-y-6">
            {/* Lease Funnel */}
            <LeaseFunnel data={dashboardData?.leases} />

            {/* Recently Viewed */}
            <RecentlyViewed />
          </div>

          {/* Right Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tasks Section */}
            <TasksSection data={dashboardData?.tasks} />

            {/* Financial Overview */}
            <FinancialOverview data={dashboardData?.financial} />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

export default withAuth(DashboardPage);
