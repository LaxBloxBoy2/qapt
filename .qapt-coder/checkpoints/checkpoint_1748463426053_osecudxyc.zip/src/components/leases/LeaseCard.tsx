"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format, parseISO } from "date-fns";
import { LeaseWithRelations } from "@/types/lease";
import { useDeleteLease } from "@/hooks/useLeases";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { LeaseForm } from "./LeaseForm";

interface LeaseCardProps {
  lease: LeaseWithRelations;
}

export function LeaseCard({ lease }: LeaseCardProps) {
  const router = useRouter();
  const deleteLease = useDeleteLease();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Format dates
  const startDate = format(parseISO(lease.start_date), "MMM d, yyyy");
  const endDate = format(parseISO(lease.end_date), "MMM d, yyyy");

  // Calculate status if missing
  const getLeaseStatus = () => {
    // Check if it's a draft first
    if (lease.is_draft) {
      return 'draft';
    }

    if (lease.status && lease.status !== 'unknown') {
      return lease.status;
    }

    const today = new Date();
    const start = parseISO(lease.start_date);
    const end = parseISO(lease.end_date);

    if (start > today) return 'upcoming';
    if (end < today) return 'expired';
    return 'active';
  };

  const currentStatus = getLeaseStatus();

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  // Helper function to get deposit amount regardless of column name
  const getDepositAmount = (lease: any) => {
    if (lease.deposit_amount !== undefined && lease.deposit_amount !== null) {
      return formatCurrency(lease.deposit_amount);
    } else if (lease.security_deposit !== undefined && lease.security_deposit !== null) {
      return formatCurrency(lease.security_deposit);
    } else if (lease.deposit !== undefined && lease.deposit !== null) {
      return formatCurrency(lease.deposit);
    } else {
      return "None";
    }
  };

  // Get status badge color
  const getStatusColor = (status: string | null | undefined) => {
    if (!status) {
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }

    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'upcoming':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'expired':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'draft':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Get primary tenant name
  const getPrimaryTenantName = () => {
    const primaryTenant = lease.primary_tenant || lease.tenants?.[0];

    if (!primaryTenant) {
      return lease.is_draft ? "Draft - No tenant assigned" : "No tenant";
    }

    return primaryTenant.is_company && primaryTenant.company_name
      ? primaryTenant.company_name
      : `${primaryTenant.first_name} ${primaryTenant.last_name}`;
  };

  // Handle delete confirmation
  const handleDelete = async () => {
    try {
      await deleteLease.mutateAsync(lease.id);
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error deleting lease:", error);
    }
  };

  // Navigate to lease detail page
  const handleViewDetails = () => {
    if (!lease.id) {
      console.error("Missing lease ID");
      return;
    }

    router.push(`/leases/${lease.id}`);
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              {lease.unit?.name || "Unknown Unit"}
              {lease.is_draft && (
                <i className="ri-draft-line text-orange-500 text-sm" title="Draft lease"></i>
              )}
            </CardTitle>
            <CardDescription>
              {lease.unit?.properties?.name || "Unknown Property"}
            </CardDescription>
          </div>
          <Badge className={getStatusColor(currentStatus)}>
            {currentStatus.charAt(0).toUpperCase() + currentStatus.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Tenant:</span>
            <span className="font-medium">{getPrimaryTenantName()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Period:</span>
            <span className="font-medium">{startDate} → {endDate}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Monthly Rent:</span>
            <span className="font-medium">{formatCurrency(lease.rent_amount)}</span>
          </div>
          {getDepositAmount(lease) !== "None" && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Security Deposit:</span>
              <span className="font-medium">{getDepositAmount(lease)}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-2 flex justify-between">
        <Button variant="outline" size="sm" onClick={handleViewDetails}>
          <i className="ri-eye-line mr-1"></i> View
        </Button>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditDialogOpen(true)}
          >
            <i className="ri-edit-line mr-1"></i>
          </Button>
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="sm">
                <i className="ri-delete-bin-line text-destructive"></i>
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete the lease for {lease.unit?.name} and remove all associated records.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardFooter>

      {/* Edit Lease Dialog */}
      <LeaseForm
        lease={lease}
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
      />
    </Card>
  );
}
