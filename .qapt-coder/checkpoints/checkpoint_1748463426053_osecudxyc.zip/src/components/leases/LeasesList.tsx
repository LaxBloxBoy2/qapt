"use client";

import { useState, useMemo } from "react";
import { useLeases } from "@/hooks/useLeases";
import { useGetUnits } from "@/hooks/useUnits";
import { useTenants } from "@/hooks/useTenants";
import { LeaseStatus, LeaseWithRelations, leaseStatuses } from "@/types/lease";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { LeaseCard } from "./LeaseCard";
import { LeaseForm } from "./LeaseForm";
import { format, parseISO } from "date-fns";

export function LeasesList() {
  const { data: leases, isLoading, isError } = useLeases();
  const { data: units } = useGetUnits();
  const { data: tenants } = useTenants();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [unitFilter, setUnitFilter] = useState<string>("all");
  const [tenantFilter, setTenantFilter] = useState<string>("all");
  const [showAddDialog, setShowAddDialog] = useState(false);

  // For debugging
  console.log("LeasesList render - leases:", leases, "isLoading:", isLoading, "isError:", isError);

  // Log lease IDs for debugging
  if (leases && leases.length > 0) {
    console.log("Available lease IDs:", leases.map(lease => ({ id: lease.id, unit: lease.unit?.name })));
  }

  // Filter leases based on search query and filters
  const filteredLeases = useMemo(() => {
    if (!leases) return [];

    return leases.filter((lease) => {
      // Search filter
      const searchLower = searchQuery.toLowerCase();
      const unitName = lease.unit?.name?.toLowerCase() || "";
      const propertyName = lease.unit?.properties?.name?.toLowerCase() || "";
      const tenantNames = lease.tenants?.map(t =>
        t.is_company && t.company_name
          ? t.company_name.toLowerCase()
          : `${t.first_name} ${t.last_name}`.toLowerCase()
      ).join(" ") || "";

      const searchMatches = !searchQuery ||
        unitName.includes(searchLower) ||
        propertyName.includes(searchLower) ||
        tenantNames.includes(searchLower) ||
        lease.rent_amount.toString().includes(searchLower);

      // Status filter
      const statusMatches = statusFilter === "all" ||
        (lease.status ? lease.status === statusFilter : false);

      // Unit filter
      const unitMatches = unitFilter === "all" || lease.unit_id === unitFilter;

      // Tenant filter
      const tenantMatches = tenantFilter === "all" ||
        lease.tenants?.some(tenant => tenant.id === tenantFilter);

      return searchMatches && statusMatches && unitMatches && tenantMatches;
    });
  }, [leases, searchQuery, statusFilter, unitFilter, tenantFilter]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Leases</h2>
        <Button onClick={() => setShowAddDialog(true)}>
          <i className="ri-add-line mr-2"></i>
          Add Lease
        </Button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <Input
            placeholder="Search leases..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        <div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {leaseStatuses.map((status) => (
                <SelectItem key={status} value={status}>
                  {status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Unknown'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Select value={unitFilter} onValueChange={setUnitFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by unit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Units</SelectItem>
              {units?.map((unit) => (
                <SelectItem key={unit.id} value={unit.id}>
                  {unit.name} ({unit.properties?.name})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Select value={tenantFilter} onValueChange={setTenantFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by tenant" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tenants</SelectItem>
              {tenants?.map((tenant) => (
                <SelectItem key={tenant.id} value={tenant.id}>
                  {tenant.is_company && tenant.company_name
                    ? tenant.company_name
                    : `${tenant.first_name} ${tenant.last_name}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Leases Grid */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="mt-2 text-muted-foreground">Loading leases...</p>
        </div>
      ) : isError ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
          <div className="inline-block rounded-full p-3 bg-red-100 dark:bg-red-900">
            <i className="ri-error-warning-line text-3xl text-red-600 dark:text-red-300"></i>
          </div>
          <h3 className="mt-4 text-lg font-medium">Error loading leases</h3>
          <p className="mt-1 text-muted-foreground">
            There was a problem loading your leases. Please try again later.
          </p>
          <Button
            className="mt-4"
            onClick={() => window.location.reload()}
          >
            <i className="ri-refresh-line mr-2"></i>
            Refresh Page
          </Button>
        </div>
      ) : filteredLeases && filteredLeases.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLeases.map((lease: LeaseWithRelations) => (
            <LeaseCard key={lease.id} lease={lease} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
          <div className="inline-block rounded-full p-3 bg-gray-100 dark:bg-gray-700">
            <i className="ri-file-list-3-line text-3xl text-muted-foreground"></i>
          </div>
          <h3 className="mt-4 text-lg font-medium">No leases found</h3>
          <p className="mt-1 text-muted-foreground">
            {searchQuery || statusFilter !== "all" || unitFilter !== "all" || tenantFilter !== "all"
              ? "Try adjusting your filters"
              : "Get started by adding your first lease"}
          </p>
          {!searchQuery && statusFilter === "all" && unitFilter === "all" && tenantFilter === "all" && (
            <Button
              className="mt-4"
              onClick={() => setShowAddDialog(true)}
            >
              <i className="ri-add-line mr-2"></i>
              Add Lease
            </Button>
          )}
        </div>
      )}

      {/* Add Lease Dialog */}
      <LeaseForm
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
      />
    </div>
  );
}
