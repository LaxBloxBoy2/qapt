"use client";

import { useGetProperties } from "@/hooks/useProperties";
import { PropertyCard } from "./PropertyCard";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function PropertyList() {
  const { data: properties, isLoading, isError, error } = useGetProperties();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-4 rounded-lg">
        <h3 className="text-lg font-semibold">Error loading properties</h3>
        <p>{error.message}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Properties</h2>
        <Link href="/properties/new">
          <Button>
            <i className="ri-add-line mr-1" />
            Add Property
          </Button>
        </Link>
      </div>

      {properties && properties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
      ) : (
        <div className="bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-lg p-8 text-center">
          <h3 className="text-lg font-medium mb-2">No properties found</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            You haven't added any properties yet. Click the button below to add your first property.
          </p>
          <Link href="/properties/new">
            <Button>
              <i className="ri-add-line mr-1" />
              Add Your First Property
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
