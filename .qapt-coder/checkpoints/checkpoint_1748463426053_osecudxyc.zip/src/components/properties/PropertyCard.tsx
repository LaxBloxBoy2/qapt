"use client";

import { Property } from "@/types/property";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { useDeleteProperty } from "@/hooks/useProperties";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import Link from "next/link";

interface PropertyCardProps {
  property: Property;
}

export function PropertyCard({ property }: PropertyCardProps) {
  const deleteProperty = useDeleteProperty();

  const handleDelete = () => {
    deleteProperty.mutate(property.id);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400";
      case "inactive":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400";
      case "archived":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400";
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400";
    }
  };

  const getPropertyTypeLabel = (type: string) => {
    return type === "single_unit" ? "Single Unit" : "Multi Unit";
  };

  return (
    <>
      <Card className="h-full flex flex-col group cursor-pointer hover:shadow-md transition-shadow">
        <Link href={`/properties/${property.id}`} className="flex-grow">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl">{property.name}</CardTitle>
                <CardDescription className="mt-1">
                  {property.address}, {property.city}, {property.state} {property.zip}
                </CardDescription>
              </div>
              <Badge className={getStatusColor(property.status)}>
                {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="grid grid-cols-2 gap-2 text-sm mb-4">
              <div>
                <span className="text-gray-500 dark:text-gray-400">Type:</span>{" "}
                {getPropertyTypeLabel(property.type)}
              </div>
              {property.year_built && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Year Built:</span>{" "}
                  {property.year_built}
                </div>
              )}
              {property.beds && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Beds:</span>{" "}
                  {property.beds}
                </div>
              )}
              {property.baths && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Baths:</span>{" "}
                  {property.baths}
                </div>
              )}
              {property.size && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Size:</span>{" "}
                  {property.size} sq ft
                </div>
              )}
              {property.market_rent && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Rent:</span>{" "}
                  ${property.market_rent.toLocaleString()}
                </div>
              )}
            </div>
            {property.description && (
              <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-3">
                {property.description}
              </p>
            )}
          </CardContent>
        </Link>
        <CardFooter className="border-t pt-4 flex justify-between">
          <Link href={`/properties/edit/${property.id}`}>
            <Button variant="outline" size="sm">
              <i className="ri-edit-line mr-1" />
              Edit
            </Button>
          </Link>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600">
                <i className="ri-delete-bin-line mr-1" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete the property "{property.name}". This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
                  {deleteProperty.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardFooter>
      </Card>
    </>
  );
}
